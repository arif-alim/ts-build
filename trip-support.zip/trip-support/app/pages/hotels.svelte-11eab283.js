import{S as t,i as e,s as l}from"../chunks/vendor-4f048286.js";class n extends t{constructor(s){super();e(this,s,null,null,l,{})}}export{n as default};
