import{S as e,i as t,s as l}from"../chunks/vendor-4f048286.js";class n extends e{constructor(s){super();t(this,s,null,null,l,{})}}export{n as default};
