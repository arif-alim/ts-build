import{S as t,i as a,s as e}from"../chunks/vendor-4f048286.js";class l extends t{constructor(s){super();a(this,s,null,null,e,{})}}export{l as default};
