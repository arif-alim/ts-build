import{S as s,i as e,s as l}from"../chunks/vendor-4f048286.js";class n extends s{constructor(t){super();e(this,t,null,null,l,{})}}export{n as default};
