var fe = Object.defineProperty,
	ue = Object.defineProperties;
var he = Object.getOwnPropertyDescriptors;
var J = Object.getOwnPropertySymbols;
var Q = Object.prototype.hasOwnProperty,
	Z = Object.prototype.propertyIsEnumerable;
var H = (a, e, t) => (e in a ? fe(a, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : (a[e] = t)),
	k = (a, e) => {
		for (var t in e || (e = {})) Q.call(e, t) && H(a, t, e[t]);
		if (J) for (var t of J(e)) Z.call(e, t) && H(a, t, e[t]);
		return a;
	},
	W = (a, e) => ue(a, he(e));
var ee = (a, e) => {
	var t = {};
	for (var r in a) Q.call(a, r) && e.indexOf(r) < 0 && (t[r] = a[r]);
	if (a != null && J) for (var r of J(a)) e.indexOf(r) < 0 && Z.call(a, r) && (t[r] = a[r]);
	return t;
};
import {
	S as de,
	i as _e,
	s as pe,
	e as me,
	c as ge,
	a as we,
	d as E,
	b as G,
	f as P,
	g as S,
	t as be,
	h as ve,
	j as ye,
	k as ke,
	l as b,
	m as $e,
	n as N,
	o as v,
	p as x,
	q as y,
	r as Ee,
	u as Re,
	v as Y,
	w as A,
	x as C,
	y as T,
	z as D,
	A as j,
	B as O,
	C as q,
	D as K,
	E as te,
} from './chunks/vendor-4f048286.js';
function Le(a) {
	let e, t, r;
	const l = [a[1] || {}];
	var i = a[0][0];
	function o(s) {
		let n = {};
		for (let c = 0; c < l.length; c += 1) n = q(n, l[c]);
		return { props: n };
	}
	return (
		i && (e = new i(o())),
		{
			c() {
				e && A(e.$$.fragment), (t = b());
			},
			l(s) {
				e && C(e.$$.fragment, s), (t = b());
			},
			m(s, n) {
				e && T(e, s, n), S(s, t, n), (r = !0);
			},
			p(s, n) {
				const c = n & 2 ? D(l, [j(s[1] || {})]) : {};
				if (i !== (i = s[0][0])) {
					if (e) {
						N();
						const f = e;
						v(f.$$.fragment, 1, 0, () => {
							O(f, 1);
						}),
							x();
					}
					i ? ((e = new i(o())), A(e.$$.fragment), y(e.$$.fragment, 1), T(e, t.parentNode, t)) : (e = null);
				} else i && e.$set(c);
			},
			i(s) {
				r || (e && y(e.$$.fragment, s), (r = !0));
			},
			o(s) {
				e && v(e.$$.fragment, s), (r = !1);
			},
			d(s) {
				s && E(t), e && O(e, s);
			},
		}
	);
}
function Se(a) {
	let e, t, r;
	const l = [a[1] || {}];
	var i = a[0][0];
	function o(s) {
		let n = { $$slots: { default: [Pe] }, $$scope: { ctx: s } };
		for (let c = 0; c < l.length; c += 1) n = q(n, l[c]);
		return { props: n };
	}
	return (
		i && (e = new i(o(a))),
		{
			c() {
				e && A(e.$$.fragment), (t = b());
			},
			l(s) {
				e && C(e.$$.fragment, s), (t = b());
			},
			m(s, n) {
				e && T(e, s, n), S(s, t, n), (r = !0);
			},
			p(s, n) {
				const c = n & 2 ? D(l, [j(s[1] || {})]) : {};
				if ((n & 525 && (c.$$scope = { dirty: n, ctx: s }), i !== (i = s[0][0]))) {
					if (e) {
						N();
						const f = e;
						v(f.$$.fragment, 1, 0, () => {
							O(f, 1);
						}),
							x();
					}
					i ? ((e = new i(o(s))), A(e.$$.fragment), y(e.$$.fragment, 1), T(e, t.parentNode, t)) : (e = null);
				} else i && e.$set(c);
			},
			i(s) {
				r || (e && y(e.$$.fragment, s), (r = !0));
			},
			o(s) {
				e && v(e.$$.fragment, s), (r = !1);
			},
			d(s) {
				s && E(t), e && O(e, s);
			},
		}
	);
}
function Ae(a) {
	let e, t, r;
	const l = [a[2] || {}];
	var i = a[0][1];
	function o(s) {
		let n = {};
		for (let c = 0; c < l.length; c += 1) n = q(n, l[c]);
		return { props: n };
	}
	return (
		i && (e = new i(o())),
		{
			c() {
				e && A(e.$$.fragment), (t = b());
			},
			l(s) {
				e && C(e.$$.fragment, s), (t = b());
			},
			m(s, n) {
				e && T(e, s, n), S(s, t, n), (r = !0);
			},
			p(s, n) {
				const c = n & 4 ? D(l, [j(s[2] || {})]) : {};
				if (i !== (i = s[0][1])) {
					if (e) {
						N();
						const f = e;
						v(f.$$.fragment, 1, 0, () => {
							O(f, 1);
						}),
							x();
					}
					i ? ((e = new i(o())), A(e.$$.fragment), y(e.$$.fragment, 1), T(e, t.parentNode, t)) : (e = null);
				} else i && e.$set(c);
			},
			i(s) {
				r || (e && y(e.$$.fragment, s), (r = !0));
			},
			o(s) {
				e && v(e.$$.fragment, s), (r = !1);
			},
			d(s) {
				s && E(t), e && O(e, s);
			},
		}
	);
}
function Te(a) {
	let e, t, r;
	const l = [a[2] || {}];
	var i = a[0][1];
	function o(s) {
		let n = { $$slots: { default: [Oe] }, $$scope: { ctx: s } };
		for (let c = 0; c < l.length; c += 1) n = q(n, l[c]);
		return { props: n };
	}
	return (
		i && (e = new i(o(a))),
		{
			c() {
				e && A(e.$$.fragment), (t = b());
			},
			l(s) {
				e && C(e.$$.fragment, s), (t = b());
			},
			m(s, n) {
				e && T(e, s, n), S(s, t, n), (r = !0);
			},
			p(s, n) {
				const c = n & 4 ? D(l, [j(s[2] || {})]) : {};
				if ((n & 521 && (c.$$scope = { dirty: n, ctx: s }), i !== (i = s[0][1]))) {
					if (e) {
						N();
						const f = e;
						v(f.$$.fragment, 1, 0, () => {
							O(f, 1);
						}),
							x();
					}
					i ? ((e = new i(o(s))), A(e.$$.fragment), y(e.$$.fragment, 1), T(e, t.parentNode, t)) : (e = null);
				} else i && e.$set(c);
			},
			i(s) {
				r || (e && y(e.$$.fragment, s), (r = !0));
			},
			o(s) {
				e && v(e.$$.fragment, s), (r = !1);
			},
			d(s) {
				s && E(t), e && O(e, s);
			},
		}
	);
}
function Oe(a) {
	let e, t, r;
	const l = [a[3] || {}];
	var i = a[0][2];
	function o(s) {
		let n = {};
		for (let c = 0; c < l.length; c += 1) n = q(n, l[c]);
		return { props: n };
	}
	return (
		i && (e = new i(o())),
		{
			c() {
				e && A(e.$$.fragment), (t = b());
			},
			l(s) {
				e && C(e.$$.fragment, s), (t = b());
			},
			m(s, n) {
				e && T(e, s, n), S(s, t, n), (r = !0);
			},
			p(s, n) {
				const c = n & 8 ? D(l, [j(s[3] || {})]) : {};
				if (i !== (i = s[0][2])) {
					if (e) {
						N();
						const f = e;
						v(f.$$.fragment, 1, 0, () => {
							O(f, 1);
						}),
							x();
					}
					i ? ((e = new i(o())), A(e.$$.fragment), y(e.$$.fragment, 1), T(e, t.parentNode, t)) : (e = null);
				} else i && e.$set(c);
			},
			i(s) {
				r || (e && y(e.$$.fragment, s), (r = !0));
			},
			o(s) {
				e && v(e.$$.fragment, s), (r = !1);
			},
			d(s) {
				s && E(t), e && O(e, s);
			},
		}
	);
}
function Pe(a) {
	let e, t, r, l;
	const i = [Te, Ae],
		o = [];
	function s(n, c) {
		return n[0][2] ? 0 : 1;
	}
	return (
		(e = s(a)),
		(t = o[e] = i[e](a)),
		{
			c() {
				t.c(), (r = b());
			},
			l(n) {
				t.l(n), (r = b());
			},
			m(n, c) {
				o[e].m(n, c), S(n, r, c), (l = !0);
			},
			p(n, c) {
				let f = e;
				(e = s(n)),
					e === f
						? o[e].p(n, c)
						: (N(),
						  v(o[f], 1, 1, () => {
								o[f] = null;
						  }),
						  x(),
						  (t = o[e]),
						  t ? t.p(n, c) : ((t = o[e] = i[e](n)), t.c()),
						  y(t, 1),
						  t.m(r.parentNode, r));
			},
			i(n) {
				l || (y(t), (l = !0));
			},
			o(n) {
				v(t), (l = !1);
			},
			d(n) {
				o[e].d(n), n && E(r);
			},
		}
	);
}
function se(a) {
	let e,
		t = a[5] && re(a);
	return {
		c() {
			(e = me('div')), t && t.c(), this.h();
		},
		l(r) {
			e = ge(r, 'DIV', { id: !0, 'aria-live': !0, 'aria-atomic': !0, style: !0 });
			var l = we(e);
			t && t.l(l), l.forEach(E), this.h();
		},
		h() {
			G(e, 'id', 'svelte-announcer'),
				G(e, 'aria-live', 'assertive'),
				G(e, 'aria-atomic', 'true'),
				P(e, 'position', 'absolute'),
				P(e, 'left', '0'),
				P(e, 'top', '0'),
				P(e, 'clip', 'rect(0 0 0 0)'),
				P(e, 'clip-path', 'inset(50%)'),
				P(e, 'overflow', 'hidden'),
				P(e, 'white-space', 'nowrap'),
				P(e, 'width', '1px'),
				P(e, 'height', '1px');
		},
		m(r, l) {
			S(r, e, l), t && t.m(e, null);
		},
		p(r, l) {
			r[5] ? (t ? t.p(r, l) : ((t = re(r)), t.c(), t.m(e, null))) : t && (t.d(1), (t = null));
		},
		d(r) {
			r && E(e), t && t.d();
		},
	};
}
function re(a) {
	let e;
	return {
		c() {
			e = be(a[6]);
		},
		l(t) {
			e = ve(t, a[6]);
		},
		m(t, r) {
			S(t, e, r);
		},
		p(t, r) {
			r & 64 && ye(e, t[6]);
		},
		d(t) {
			t && E(e);
		},
	};
}
function Ue(a) {
	let e, t, r, l, i;
	const o = [Se, Le],
		s = [];
	function n(f, h) {
		return f[0][1] ? 0 : 1;
	}
	(e = n(a)), (t = s[e] = o[e](a));
	let c = a[4] && se(a);
	return {
		c() {
			t.c(), (r = ke()), c && c.c(), (l = b());
		},
		l(f) {
			t.l(f), (r = $e(f)), c && c.l(f), (l = b());
		},
		m(f, h) {
			s[e].m(f, h), S(f, r, h), c && c.m(f, h), S(f, l, h), (i = !0);
		},
		p(f, [h]) {
			let u = e;
			(e = n(f)),
				e === u
					? s[e].p(f, h)
					: (N(),
					  v(s[u], 1, 1, () => {
							s[u] = null;
					  }),
					  x(),
					  (t = s[e]),
					  t ? t.p(f, h) : ((t = s[e] = o[e](f)), t.c()),
					  y(t, 1),
					  t.m(r.parentNode, r)),
				f[4] ? (c ? c.p(f, h) : ((c = se(f)), c.c(), c.m(l.parentNode, l))) : c && (c.d(1), (c = null));
		},
		i(f) {
			i || (y(t), (i = !0));
		},
		o(f) {
			v(t), (i = !1);
		},
		d(f) {
			s[e].d(f), f && E(r), c && c.d(f), f && E(l);
		},
	};
}
function Ve(a, e, t) {
	let { stores: r } = e,
		{ page: l } = e,
		{ components: i } = e,
		{ props_0: o = null } = e,
		{ props_1: s = null } = e,
		{ props_2: n = null } = e;
	Ee('__svelte__', r), Re(r.page.notify);
	let c = !1,
		f = !1,
		h = null;
	return (
		Y(() => {
			const u = r.page.subscribe(() => {
				c && (t(5, (f = !0)), t(6, (h = document.title || 'untitled page')));
			});
			return t(4, (c = !0)), u;
		}),
		(a.$$set = (u) => {
			'stores' in u && t(7, (r = u.stores)),
				'page' in u && t(8, (l = u.page)),
				'components' in u && t(0, (i = u.components)),
				'props_0' in u && t(1, (o = u.props_0)),
				'props_1' in u && t(2, (s = u.props_1)),
				'props_2' in u && t(3, (n = u.props_2));
		}),
		(a.$$.update = () => {
			a.$$.dirty & 384 && r.page.set(l);
		}),
		[i, o, s, n, c, f, h, r, l]
	);
}
class Ie extends de {
	constructor(e) {
		super();
		_e(this, e, Ve, Ue, pe, { stores: 7, page: 8, components: 0, props_0: 1, props_1: 2, props_2: 3 });
	}
}
const Ne = 'modulepreload',
	ie = {},
	xe = '/app/',
	U = function (e, t) {
		return !t || t.length === 0
			? e()
			: Promise.all(
					t.map((r) => {
						if (((r = `${xe}${r}`), r in ie)) return;
						ie[r] = !0;
						const l = r.endsWith('.css'),
							i = l ? '[rel="stylesheet"]' : '';
						if (document.querySelector(`link[href="${r}"]${i}`)) return;
						const o = document.createElement('link');
						if (
							((o.rel = l ? 'stylesheet' : Ne),
							l || ((o.as = 'script'), (o.crossOrigin = '')),
							(o.href = r),
							document.head.appendChild(o),
							l)
						)
							return new Promise((s, n) => {
								o.addEventListener('load', s),
									o.addEventListener('error', () => n(new Error(`Unable to preload CSS for ${r}`)));
							});
					})
			  ).then(() => e());
	},
	_ = [
		() =>
			U(
				() => import('./pages/__layout.svelte-ab9315ee.js'),
				['pages/__layout.svelte-ab9315ee.js', 'assets/pages/__layout.svelte-2b7a2dbd.css', 'chunks/vendor-4f048286.js']
			),
		() => U(() => import('./error.svelte-c4086c50.js'), ['error.svelte-c4086c50.js', 'chunks/vendor-4f048286.js']),
		() =>
			U(
				() => import('./pages/index.svelte-fbb8a98d.js'),
				['pages/index.svelte-fbb8a98d.js', 'chunks/vendor-4f048286.js', 'chunks/BookingWidget-206a715d.js']
			),
		() =>
			U(
				() => import('./pages/book-now-pay-later.svelte-68f1dfdd.js'),
				['pages/book-now-pay-later.svelte-68f1dfdd.js', 'chunks/vendor-4f048286.js']
			),
		() =>
			U(
				() => import('./pages/flight-hotel.svelte-dc1f25f6.js'),
				['pages/flight-hotel.svelte-dc1f25f6.js', 'chunks/vendor-4f048286.js']
			),
		() =>
			U(
				() => import('./pages/vacations.svelte-b88833ad.js'),
				['pages/vacations.svelte-b88833ad.js', 'chunks/vendor-4f048286.js']
			),
		() =>
			U(
				() => import('./pages/explore.svelte-13114674.js'),
				['pages/explore.svelte-13114674.js', 'chunks/vendor-4f048286.js']
			),
		() =>
			U(
				() => import('./pages/flights.svelte-fcdfc230.js'),
				['pages/flights.svelte-fcdfc230.js', 'chunks/vendor-4f048286.js', 'chunks/BookingWidget-206a715d.js']
			),
		() =>
			U(
				() => import('./pages/hotels.svelte-11eab283.js'),
				['pages/hotels.svelte-11eab283.js', 'chunks/vendor-4f048286.js']
			),
	],
	Ce = [
		[/^\/$/, [_[0], _[2]], [_[1]]],
		[/^\/book-now-pay-later\/?$/, [_[0], _[3]], [_[1]]],
		[/^\/flight-hotel\/?$/, [_[0], _[4]], [_[1]]],
		[/^\/vacations\/?$/, [_[0], _[5]], [_[1]]],
		[/^\/explore\/?$/, [_[0], _[6]], [_[1]]],
		[/^\/flights\/?$/, [_[0], _[7]], [_[1]]],
		[/^\/hotels\/?$/, [_[0], _[8]], [_[1]]],
	],
	De = [_[0](), _[1]()];
function je(a) {
	let e = a.baseURI;
	if (!e) {
		const t = a.getElementsByTagName('base');
		e = t.length ? t[0].href : a.URL;
	}
	return e;
}
let F = '';
function qe(a) {
	(F = a.base), a.assets;
}
function ze(a, e) {
	return a === '/' || e === 'ignore'
		? a
		: e === 'never'
		? a.endsWith('/')
			? a.slice(0, -1)
			: a
		: e === 'always' && /\/[^./]+$/.test(a)
		? a + '/'
		: a;
}
function M() {
	return { x: pageXOffset, y: pageYOffset };
}
function ne(a) {
	return a.composedPath().find((t) => t instanceof Node && t.nodeName.toUpperCase() === 'A');
}
function ae(a) {
	return a instanceof SVGAElement ? new URL(a.href.baseVal, document.baseURI) : new URL(a.href);
}
class Be {
	constructor({ base: e, routes: t, trailing_slash: r, renderer: l }) {
		var i, o;
		(this.base = e),
			(this.routes = t),
			(this.trailing_slash = r),
			(this.navigating = 0),
			(this.renderer = l),
			(l.router = this),
			(this.enabled = !0),
			document.body.setAttribute('tabindex', '-1'),
			(this.current_history_index = (o = (i = history.state) == null ? void 0 : i['sveltekit:index']) != null ? o : 0),
			this.current_history_index === 0 &&
				history.replaceState(W(k({}, history.state), { 'sveltekit:index': 0 }), '', location.href),
			(this.callbacks = { before_navigate: [], after_navigate: [] });
	}
	init_listeners() {
		'scrollRestoration' in history && (history.scrollRestoration = 'manual'),
			addEventListener('beforeunload', (i) => {
				let o = !1;
				const s = { from: this.renderer.current.url, to: null, cancel: () => (o = !0) };
				this.callbacks.before_navigate.forEach((n) => n(s)),
					o ? (i.preventDefault(), (i.returnValue = '')) : (history.scrollRestoration = 'auto');
			}),
			addEventListener('load', () => {
				history.scrollRestoration = 'manual';
			});
		let e;
		addEventListener('scroll', () => {
			clearTimeout(e),
				(e = setTimeout(() => {
					const i = W(k({}, history.state || {}), { 'sveltekit:scroll': M() });
					history.replaceState(i, document.title, window.location.href);
				}, 200));
		});
		const t = (i) => {
			const o = ne(i);
			o && o.href && o.hasAttribute('sveltekit:prefetch') && this.prefetch(ae(o));
		};
		let r;
		const l = (i) => {
			clearTimeout(r),
				(r = setTimeout(() => {
					var o;
					(o = i.target) == null || o.dispatchEvent(new CustomEvent('sveltekit:trigger_prefetch', { bubbles: !0 }));
				}, 20));
		};
		addEventListener('touchstart', t),
			addEventListener('mousemove', l),
			addEventListener('sveltekit:trigger_prefetch', t),
			addEventListener('click', (i) => {
				if (
					!this.enabled ||
					i.button ||
					i.which !== 1 ||
					i.metaKey ||
					i.ctrlKey ||
					i.shiftKey ||
					i.altKey ||
					i.defaultPrevented
				)
					return;
				const o = ne(i);
				if (!o || !o.href) return;
				const s = ae(o);
				if (s.toString() === location.href) {
					location.hash || i.preventDefault();
					return;
				}
				const c = (o.getAttribute('rel') || '').split(/\s+/);
				if (
					o.hasAttribute('download') ||
					(c && c.includes('external')) ||
					(o instanceof SVGAElement ? o.target.baseVal : o.target)
				)
					return;
				const [f, h] = s.href.split('#');
				if (h !== void 0 && f === location.href.split('#')[0]) {
					setTimeout(() => history.pushState({}, '', s.href));
					const u = this.parse(s);
					return u ? this.renderer.update(u, [], !1) : void 0;
				}
				this._navigate({
					url: s,
					scroll: o.hasAttribute('sveltekit:noscroll') ? M() : null,
					keepfocus: !1,
					chain: [],
					details: { state: {}, replaceState: !1 },
					accepted: () => i.preventDefault(),
					blocked: () => i.preventDefault(),
				});
			}),
			addEventListener('popstate', (i) => {
				if (i.state && this.enabled) {
					if (i.state['sveltekit:index'] === this.current_history_index) return;
					this._navigate({
						url: new URL(location.href),
						scroll: i.state['sveltekit:scroll'],
						keepfocus: !1,
						chain: [],
						details: null,
						accepted: () => {
							this.current_history_index = i.state['sveltekit:index'];
						},
						blocked: () => {
							const o = this.current_history_index - i.state['sveltekit:index'];
							history.go(o);
						},
					});
				}
			});
	}
	owns(e) {
		return e.origin === location.origin && e.pathname.startsWith(this.base);
	}
	parse(e) {
		if (this.owns(e)) {
			const t = decodeURI(e.pathname.slice(this.base.length) || '/');
			return { id: e.pathname + e.search, routes: this.routes.filter(([r]) => r.test(t)), url: e, path: t };
		}
	}
	async goto(e, { noscroll: t = !1, replaceState: r = !1, keepfocus: l = !1, state: i = {} } = {}, o) {
		const s = new URL(e, je(document));
		return this.enabled
			? this._navigate({
					url: s,
					scroll: t ? M() : null,
					keepfocus: l,
					chain: o,
					details: { state: i, replaceState: r },
					accepted: () => {},
					blocked: () => {},
			  })
			: ((location.href = s.href), new Promise(() => {}));
	}
	enable() {
		this.enabled = !0;
	}
	disable() {
		this.enabled = !1;
	}
	async prefetch(e) {
		const t = this.parse(e);
		if (!t) throw new Error('Attempted to prefetch a URL that does not belong to this app');
		return this.renderer.load(t);
	}
	after_navigate(e) {
		Y(
			() => (
				this.callbacks.after_navigate.push(e),
				() => {
					const t = this.callbacks.after_navigate.indexOf(e);
					this.callbacks.after_navigate.splice(t, 1);
				}
			)
		);
	}
	before_navigate(e) {
		Y(
			() => (
				this.callbacks.before_navigate.push(e),
				() => {
					const t = this.callbacks.before_navigate.indexOf(e);
					this.callbacks.before_navigate.splice(t, 1);
				}
			)
		);
	}
	async _navigate({ url: e, scroll: t, keepfocus: r, chain: l, details: i, accepted: o, blocked: s }) {
		const n = this.renderer.current.url;
		let c = !1;
		const f = { from: n, to: e, cancel: () => (c = !0) };
		if ((this.callbacks.before_navigate.forEach((d) => d(f)), c)) {
			s();
			return;
		}
		const h = this.parse(e);
		if (!h) return (location.href = e.href), new Promise(() => {});
		o(), this.navigating || dispatchEvent(new CustomEvent('sveltekit:navigation-start')), this.navigating++;
		const u = ze(e.pathname, this.trailing_slash);
		if (((h.url = new URL(e.origin + u + e.search + e.hash)), i)) {
			const d = i.replaceState ? 0 : 1;
			(i.state['sveltekit:index'] = this.current_history_index += d),
				history[i.replaceState ? 'replaceState' : 'pushState'](i.state, '', h.url);
		}
		if (
			(await this.renderer.handle_navigation(h, l, !1, { scroll: t, keepfocus: r }),
			this.navigating--,
			!this.navigating)
		) {
			dispatchEvent(new CustomEvent('sveltekit:navigation-end'));
			const d = { from: n, to: e };
			this.callbacks.after_navigate.forEach((p) => p(d));
		}
	}
}
function oe(a) {
	return a instanceof Error || (a && a.name && a.message) ? a : new Error(JSON.stringify(a));
}
function Je(a) {
	let e = 5381,
		t = a.length;
	if (typeof a == 'string') for (; t; ) e = (e * 33) ^ a.charCodeAt(--t);
	else for (; t; ) e = (e * 33) ^ a[--t];
	return (e >>> 0).toString(36);
}
function le(a) {
	const e = a.status && a.status >= 400 && a.status <= 599 && !a.redirect;
	if (a.error || e) {
		const t = a.status;
		if (!a.error && e) return { status: t || 500, error: new Error() };
		const r = typeof a.error == 'string' ? new Error(a.error) : a.error;
		return r instanceof Error
			? !t || t < 400 || t > 599
				? (console.warn('"error" returned from load() without a valid status code \u2014 defaulting to 500'),
				  { status: 500, error: r })
				: { status: t, error: r }
			: {
					status: 500,
					error: new Error(
						`"error" property returned from load() must be a string or instance of Error, received type "${typeof r}"`
					),
			  };
	}
	if (a.redirect) {
		if (!a.status || Math.floor(a.status / 100) !== 3)
			return {
				status: 500,
				error: new Error('"redirect" property returned from load() must be accompanied by a 3xx status code'),
			};
		if (typeof a.redirect != 'string')
			return { status: 500, error: new Error('"redirect" property returned from load() must be a string') };
	}
	if (a.context)
		throw new Error(
			'You are returning "context" from a load function. "context" was renamed to "stuff", please adjust your code accordingly.'
		);
	return a;
}
function ce(a) {
	const e = K(a);
	let t = !0;
	function r() {
		(t = !0), e.update((o) => o);
	}
	function l(o) {
		(t = !1), e.set(o);
	}
	function i(o) {
		let s;
		return e.subscribe((n) => {
			(s === void 0 || (t && n !== s)) && o((s = n));
		});
	}
	return { notify: r, set: l, subscribe: i };
}
function Ke() {
	const { set: a, subscribe: e } = K(!1),
		t = '1646326562315';
	let r;
	async function l() {
		clearTimeout(r);
		const o = await fetch(`${F}/app/version.json`, { headers: { pragma: 'no-cache', 'cache-control': 'no-cache' } });
		if (o.ok) {
			const { version: s } = await o.json(),
				n = s !== t;
			return n && (a(!0), clearTimeout(r)), n;
		} else throw new Error(`Version check failed: ${o.status}`);
	}
	return { subscribe: e, check: l };
}
function We(a, e) {
	const t = typeof a == 'string' ? a : a.url;
	let r = `script[data-type="svelte-data"][data-url=${JSON.stringify(t)}]`;
	e && typeof e.body == 'string' && (r += `[data-body="${Je(e.body)}"]`);
	const l = document.querySelector(r);
	if (l && l.textContent) {
		const i = JSON.parse(l.textContent),
			{ body: o } = i,
			s = ee(i, ['body']);
		return Promise.resolve(new Response(o, s));
	}
	return fetch(a, e);
}
class Ge {
	constructor({ Root: e, fallback: t, target: r, session: l }) {
		(this.Root = e),
			(this.fallback = t),
			this.router,
			(this.target = r),
			(this.started = !1),
			(this.session_id = 1),
			(this.invalid = new Set()),
			(this.invalidating = null),
			(this.autoscroll = !0),
			(this.updating = !1),
			(this.current = { url: null, session_id: 0, branch: [] }),
			(this.cache = new Map()),
			(this.loading = { id: null, promise: null }),
			(this.stores = { url: ce({}), page: ce({}), navigating: K(null), session: K(l), updated: Ke() }),
			(this.$session = null),
			(this.root = null);
		let i = !1;
		this.stores.session.subscribe(async (o) => {
			if (((this.$session = o), !i || !this.router)) return;
			this.session_id += 1;
			const s = this.router.parse(new URL(location.href));
			s && this.update(s, [], !0);
		}),
			(i = !0);
	}
	disable_scroll_handling() {
		(this.updating || !this.started) && (this.autoscroll = !1);
	}
	async start({ status: e, error: t, nodes: r, url: l, params: i }) {
		const o = [];
		let s = {},
			n,
			c;
		l.hash = window.location.hash;
		try {
			for (let f = 0; f < r.length; f += 1) {
				const h = f === r.length - 1;
				let u;
				if (h) {
					const p = document.querySelector('[data-type="svelte-props"]');
					p && (u = JSON.parse(p.textContent));
				}
				const d = await this._load_node({
					module: await r[f],
					url: l,
					params: i,
					stuff: s,
					status: h ? e : void 0,
					error: h ? t : void 0,
					props: u,
				});
				if ((u && d.uses.dependencies.add(l.href), o.push(d), d && d.loaded))
					if (d.loaded.error) {
						if (t) throw d.loaded.error;
						c = { status: d.loaded.status, error: d.loaded.error, url: l };
					} else d.loaded.stuff && (s = k(k({}, s), d.loaded.stuff));
			}
			n = c
				? await this._load_error(c)
				: await this._get_navigation_result_from_branch({
						url: l,
						params: i,
						stuff: s,
						branch: o,
						status: e,
						error: t,
				  });
		} catch (f) {
			if (t) throw f;
			n = await this._load_error({ status: 500, error: oe(f), url: l });
		}
		if (n.redirect) {
			location.href = new URL(n.redirect, location.href).href;
			return;
		}
		this._init(n);
	}
	async handle_navigation(e, t, r, l) {
		this.started && this.stores.navigating.set({ from: this.current.url, to: e.url }), await this.update(e, t, r, l);
	}
	async update(e, t, r, l) {
		var n, c, f;
		const i = (this.token = {});
		let o = await this._get_navigation_result(e, r);
		if (i !== this.token) return;
		if ((this.invalid.clear(), o.redirect))
			if (t.length > 10 || t.includes(e.url.pathname))
				o = await this._load_error({ status: 500, error: new Error('Redirect loop'), url: e.url });
			else {
				this.router
					? this.router.goto(new URL(o.redirect, e.url).href, { replaceState: !0 }, [...t, e.url.pathname])
					: (location.href = new URL(o.redirect, location.href).href);
				return;
			}
		else if (
			((c = (n = o.props) == null ? void 0 : n.page) == null ? void 0 : c.status) >= 400 &&
			(await this.stores.updated.check())
		) {
			location.href = e.url.href;
			return;
		}
		if (
			((this.updating = !0),
			this.started
				? ((this.current = o.state), this.root.$set(o.props), this.stores.navigating.set(null))
				: this._init(o),
			l)
		) {
			const { scroll: h, keepfocus: u } = l;
			if (
				(u || ((f = getSelection()) == null || f.removeAllRanges(), document.body.focus()), await te(), this.autoscroll)
			) {
				const d = e.url.hash && document.getElementById(e.url.hash.slice(1));
				h ? scrollTo(h.x, h.y) : d ? d.scrollIntoView() : scrollTo(0, 0);
			}
		} else await te();
		if (
			((this.loading.promise = null),
			(this.loading.id = null),
			(this.autoscroll = !0),
			(this.updating = !1),
			!this.router)
		)
			return;
		const s = o.state.branch[o.state.branch.length - 1];
		s && s.module.router === !1 ? this.router.disable() : this.router.enable();
	}
	load(e) {
		return (this.loading.promise = this._get_navigation_result(e, !1)), (this.loading.id = e.id), this.loading.promise;
	}
	invalidate(e) {
		return (
			this.invalid.add(e),
			this.invalidating ||
				(this.invalidating = Promise.resolve().then(async () => {
					const t = this.router && this.router.parse(new URL(location.href));
					t && (await this.update(t, [], !0)), (this.invalidating = null);
				})),
			this.invalidating
		);
	}
	_init(e) {
		this.current = e.state;
		const t = document.querySelector('style[data-svelte]');
		if (
			(t && t.remove(),
			(this.root = new this.Root({ target: this.target, props: k({ stores: this.stores }, e.props), hydrate: !0 })),
			(this.started = !0),
			this.router)
		) {
			const r = { from: null, to: new URL(location.href) };
			this.router.callbacks.after_navigate.forEach((l) => l(r));
		}
	}
	async _get_navigation_result(e, t) {
		if (this.loading.id === e.id && this.loading.promise) return this.loading.promise;
		for (let r = 0; r < e.routes.length; r += 1) {
			const l = e.routes[r];
			let i = r + 1;
			for (; i < e.routes.length; ) {
				const s = e.routes[i];
				if (s[0].toString() === l[0].toString()) s[1].forEach((n) => n()), (i += 1);
				else break;
			}
			const o = await this._load({ route: l, info: e }, t);
			if (o) return o;
		}
		return await this._load_error({ status: 404, error: new Error(`Not found: ${e.url.pathname}`), url: e.url });
	}
	async _get_navigation_result_from_branch({ url: e, params: t, stuff: r, branch: l, status: i, error: o }) {
		const s = l.filter(Boolean),
			n = s.find((u) => u.loaded && u.loaded.redirect),
			c = {
				redirect: n && n.loaded ? n.loaded.redirect : void 0,
				state: { url: e, params: t, branch: l, session_id: this.session_id },
				props: { components: s.map((u) => u.module.default) },
			};
		for (let u = 0; u < s.length; u += 1) {
			const d = s[u].loaded;
			c.props[`props_${u}`] = d ? await d.props : null;
		}
		if (!this.current.url || e.href !== this.current.url.href) {
			c.props.page = { url: e, params: t, status: i, error: o, stuff: r };
			const u = (d, p) => {
				Object.defineProperty(c.props.page, d, {
					get: () => {
						throw new Error(`$page.${d} has been replaced by $page.url.${p}`);
					},
				});
			};
			u('origin', 'origin'), u('path', 'pathname'), u('query', 'searchParams');
		}
		const f = s[s.length - 1],
			h = f.loaded && f.loaded.maxage;
		if (h) {
			const u = e.pathname + e.search;
			let d = !1;
			const p = () => {
					this.cache.get(u) === c && this.cache.delete(u), R(), clearTimeout(V);
				},
				V = setTimeout(p, h * 1e3),
				R = this.stores.session.subscribe(() => {
					d && p();
				});
			(d = !0), this.cache.set(u, c);
		}
		return c;
	}
	async _load_node({ status: e, error: t, module: r, url: l, params: i, stuff: o, props: s }) {
		const n = {
			module: r,
			uses: { params: new Set(), url: !1, session: !1, stuff: !1, dependencies: new Set() },
			loaded: null,
			stuff: o,
		};
		s && n.uses.dependencies.add(l.href);
		const c = {};
		for (const h in i)
			Object.defineProperty(c, h, {
				get() {
					return n.uses.params.add(h), i[h];
				},
				enumerable: !0,
			});
		const f = this.$session;
		if (r.load) {
			const { started: h } = this,
				u = {
					params: c,
					props: s || {},
					get url() {
						return (n.uses.url = !0), l;
					},
					get session() {
						return (n.uses.session = !0), f;
					},
					get stuff() {
						return (n.uses.stuff = !0), k({}, o);
					},
					fetch(p, V) {
						const R = typeof p == 'string' ? p : p.url,
							{ href: L } = new URL(R, l);
						return n.uses.dependencies.add(L), h ? fetch(p, V) : We(p, V);
					},
				};
			t && ((u.status = e), (u.error = t));
			const d = await r.load.call(null, u);
			if (!d) throw new Error('load function must return a value');
			(n.loaded = le(d)), n.loaded.stuff && (n.stuff = n.loaded.stuff);
		} else s && (n.loaded = le({ props: s }));
		return n;
	}
	async _load({ route: e, info: { url: t, path: r } }, l) {
		const i = t.pathname + t.search;
		if (!l) {
			const m = this.cache.get(i);
			if (m) return m;
		}
		const [o, s, n, c, f] = e,
			h = c ? c(o.exec(r)) : {},
			u = this.current.url && {
				url: i !== this.current.url.pathname + this.current.url.search,
				params: Object.keys(h).filter((m) => this.current.params[m] !== h[m]),
				session: this.session_id !== this.current.session_id,
			};
		let d = [],
			p = {},
			V = !1,
			R = 200,
			L;
		s.forEach((m) => m());
		e: for (let m = 0; m < s.length; m += 1) {
			let g;
			try {
				if (!s[m]) continue;
				const w = await s[m](),
					$ = this.current.branch[m];
				if (
					!$ ||
					w !== $.module ||
					(u.url && $.uses.url) ||
					u.params.some((I) => $.uses.params.has(I)) ||
					(u.session && $.uses.session) ||
					Array.from($.uses.dependencies).some((I) => this.invalid.has(I)) ||
					(V && $.uses.stuff)
				) {
					let I = {};
					if (f && m === s.length - 1) {
						const B = await fetch(`${t.pathname}${t.pathname.endsWith('/') ? '' : '/'}__data.json`, {
							headers: { 'x-sveltekit-noredirect': 'true' },
						});
						if (B.ok) {
							const X = B.headers.get('x-sveltekit-location');
							if (X) return { redirect: X, props: {}, state: this.current };
							I = await B.json();
						} else (R = B.status), (L = new Error('Failed to load data'));
					}
					if ((L || (g = await this._load_node({ module: w, url: t, params: h, props: I, stuff: p })), g && g.loaded)) {
						if (g.loaded.fallthrough) return;
						if ((g.loaded.error && ((R = g.loaded.status), (L = g.loaded.error)), g.loaded.redirect))
							return { redirect: g.loaded.redirect, props: {}, state: this.current };
						g.loaded.stuff && (V = !0);
					}
				} else g = $;
			} catch (w) {
				(R = 500), (L = oe(w));
			}
			if (L) {
				for (; m--; )
					if (n[m]) {
						let w,
							$,
							z = m;
						for (; !($ = d[z]); ) z -= 1;
						try {
							if (
								((w = await this._load_node({
									status: R,
									error: L,
									module: await n[m](),
									url: t,
									params: h,
									stuff: $.stuff,
								})),
								w && w.loaded && w.loaded.error)
							)
								continue;
							w && w.loaded && w.loaded.stuff && (p = k(k({}, p), w.loaded.stuff)), (d = d.slice(0, z + 1).concat(w));
							break e;
						} catch {
							continue;
						}
					}
				return await this._load_error({ status: R, error: L, url: t });
			} else g && g.loaded && g.loaded.stuff && (p = k(k({}, p), g.loaded.stuff)), d.push(g);
		}
		return await this._get_navigation_result_from_branch({
			url: t,
			params: h,
			stuff: p,
			branch: d,
			status: R,
			error: L,
		});
	}
	async _load_error({ status: e, error: t, url: r }) {
		var c, f;
		const l = {},
			i = await this._load_node({ module: await this.fallback[0], url: r, params: l, stuff: {} }),
			o = await this._load_node({
				status: e,
				error: t,
				module: await this.fallback[1],
				url: r,
				params: l,
				stuff: (i && i.loaded && i.loaded.stuff) || {},
			}),
			s = [i, o],
			n = k(
				k({}, (c = i == null ? void 0 : i.loaded) == null ? void 0 : c.stuff),
				(f = o == null ? void 0 : o.loaded) == null ? void 0 : f.stuff
			);
		return await this._get_navigation_result_from_branch({
			url: r,
			params: l,
			stuff: n,
			branch: s,
			status: e,
			error: t,
		});
	}
}
async function Fe({ paths: a, target: e, session: t, route: r, spa: l, trailing_slash: i, hydrate: o }) {
	const s = new Ge({ Root: Ie, fallback: De, target: e, session: t }),
		n = r ? new Be({ base: a.base, routes: Ce, trailing_slash: i, renderer: s }) : null;
	qe(a),
		o && (await s.start(o)),
		n && (l && n.goto(location.href, { replaceState: !0 }, []), n.init_listeners()),
		dispatchEvent(new CustomEvent('sveltekit:start'));
}
export { Fe as start };
